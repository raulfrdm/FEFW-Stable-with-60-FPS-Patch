Eden keeps its settings, saves and shader cache in this folder. Delete it to use %APPDATA%\eden instead.
